﻿using System;
using System.Collections.Generic;

namespace Game
{
    class Shadow : Ghost
    {
        public Shadow(int row, int column, char symbol)
            : base(row, column, symbol)
        {
            this.Direction = Ghost.Way.Up;
            this.IsEaten = false;
            this.homeColumn = column;
            this.homeRow = row;
        }

        /// <summary>
        /// Overrides abstract method in base class Ghost.
        /// movement for multi-player
        /// </summary>
        public override void MoveGhost(Pacman pacman1, Pacman pacman2)
        {
            if (this.IsEaten)
            {
                FigureWhatToPrintOnExsitingPosition();
                GhostGoesHome();
                PrintEngine.PrintSymbol(this.Row, this.Column, this.Symbol);
                if (this.Row == this.HomeRow && this.Column == this.HomeColumn)
                {
                    this.Symbol = Maze.symbolGhostRedShadow;
                    this.isEaten = false;
                }
            }
            else if (pacman2.CanEatGhosts || pacman1.CanEatGhosts)
            {
                // crossroad
                if (IsCrossRoad())
                {
                    // might change direction
                    ChangeToWhereAvailableDirection();
                    // move one position
                    MoveOneStepBasedOnDirection();
                }
                else // continue on existing direction
                {
                    MoveOneStepBasedOnDirection();
                }
            }
            else
            {
                FigureWhatToPrintOnExsitingPosition();

                if (DistanceToPacman(pacman1) < DistanceToPacman(pacman2))
                {
                    if (DistanceToPacman(pacman1) < 10)
                    {

                        FigureWhatToPrintOnExsitingPosition();

                        Coordinates nextStep = this.FindNextStep(pacman1.Row, pacman1.Column);

                        this.row = nextStep.Row;
                        this.column = nextStep.Coll;

                        this.ChangeDirection(nextStep);
                        PrintEngine.PrintSymbol(this.Row, this.Column, this.Symbol);
                    }
                    else
                    {
                        Ambush(pacman1);
                    }
                }
                else
                {
                    if (DistanceToPacman(pacman2) < 10)
                    {

                        FigureWhatToPrintOnExsitingPosition();

                        Coordinates nextStep = this.FindNextStep(pacman2.Row, pacman2.Column);

                        this.row = nextStep.Row;
                        this.column = nextStep.Coll;

                        ChangeDirection(nextStep);
                        PrintEngine.PrintSymbol(this.Row, this.Column, this.Symbol);
                    }
                    else
                    {
                        Ambush(pacman2);
                    }
                }

                PrintEngine.PrintSymbol(this.Row, this.Column, this.Symbol);

            }
        }

        /// <summary>
        /// Overrides abstract method in base class Ghost.
        /// movement for single player
        /// </summary>
        public override void MoveGhost(Pacman pacman)
        {

            if (this.IsEaten)
            {
                FigureWhatToPrintOnExsitingPosition();
                GhostGoesHome();
                PrintEngine.PrintSymbol(this.Row, this.Column, this.Symbol);
                if (this.Row == this.HomeRow && this.Column == this.HomeColumn)
                {
                    this.Symbol = Maze.symbolGhostRedShadow;
                    this.isEaten = false;
                }
            }
            else if (pacman.CanEatGhosts)
            {
                // crossroad
                if (IsCrossRoad())
                {
                    ChangeToWhereAvailableDirection();
                    MoveOneStepBasedOnDirection();
                }
                else // continue on existing direction
                {
                    MoveOneStepBasedOnDirection();
                }
            }
            else
            {
                if (DistanceToPacman(pacman) < 10)
                {

                    FigureWhatToPrintOnExsitingPosition();

                    Coordinates nextStep = this.FindNextStep(pacman.Row, pacman.Column);

                    this.row = nextStep.Row;
                    this.column = nextStep.Coll;

                    ChangeDirection(nextStep);
                    PrintEngine.PrintSymbol(this.Row, this.Column, this.Symbol);
                }
                else
                {
                    Ambush(pacman);
                }
            }
        }

        /// <summary>
        /// Moves the current ghost so that it ambushes pacman.
        /// </summary>
        private void Ambush(Pacman pacman)
        {
            FigureWhatToPrintOnExsitingPosition();
            Coordinates nextStep = FindPositionToAmbush(pacman);
            nextStep = FindNextStep(nextStep.Row, nextStep.Coll);
            this.row = nextStep.Row;
            this.column = nextStep.Coll;
            PrintEngine.PrintSymbol(this.Row, this.Column, this.Symbol);
        }

        /// <summary>
        /// Helper method for the "ambushing" algorithm.
        /// </summary>
        private Coordinates FindPositionToAmbush(Pacman pacman)
        {
            double direction = 0;

            switch (pacman.Direction)
            {
                case Pacman.Way.Down: direction = Math.PI / 2; break;
                case Pacman.Way.Right: direction = 0; break;
                case Pacman.Way.Up: direction = (3 * Math.PI) / 2; break;
                case Pacman.Way.Left: direction = Math.PI; break;
            }

            for(double i = 0; i < Math.PI; i += 0.1)
            {
                int x = (int)Math.Ceiling(10 * Math.Cos(direction + i)) + pacman.Column;
                int y = (int)Math.Ceiling(10 * Math.Sin(direction + i)) + pacman.Row;

                if (!Maze.IsWall(y, x))
                {
                    return new Coordinates(y, x);
                }

                x = (int)Math.Ceiling(10 * Math.Cos(direction - i)) + pacman.Column;
                y = (int)Math.Ceiling(10 * Math.Sin(direction - i)) + pacman.Row;

                if (!Maze.IsWall(y, x))
                {
                    return new Coordinates(y, x);
                }
            }

            return new Coordinates(pacman.Row, pacman.Column);
        }
    }
}
