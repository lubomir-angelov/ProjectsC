﻿using System;
using System.Runtime.Remoting;

namespace Game
{
    class Pokey : Ghost
    {
        public Pokey(int row, int column, char symbol)
            : base(row, column, symbol)
        {
            this.Direction = Way.Up;
            this.IsEaten = false;
            this.homeColumn = column;
            this.homeRow = row;
        }

        /// <summary>
        /// Overrides abstract method in base class Ghost.
        /// ghost movement for multi-player
        /// </summary>
        public override void MoveGhost(Pacman pacman1, Pacman pacman2)
        {
            if (this.IsEaten)
            {
                FigureWhatToPrintOnExsitingPosition();
                GhostGoesHome();
                PrintEngine.PrintSymbol(this.Row, this.Column, this.Symbol);
                if (this.Row == this.HomeRow && this.Column == this.HomeColumn)
                {
                    this.Symbol = Maze.symbolGhostOrangePokey;
                    this.isEaten = false;
                }
            }
            else if (pacman1.CanEatGhosts || pacman2.CanEatGhosts)
            {
                // crossroad
                if (IsCrossRoad())
                {
                    // might change direction
                    ChangeToWhereAvailableDirection();
                    // move one position
                    MoveOneStepBasedOnDirection();
                }
                else // continue on existing direction
                {
                    MoveOneStepBasedOnDirection();
                }
            }
            else if (!pacman1.CanEatGhosts && !pacman2.CanEatGhosts)
            {
                // crossroad
                if (IsCrossRoad())
                {
                    // might change direction
                    ChangeToWhereAvailableDirection();
                    // move one position
                    MoveOneStepBasedOnDirection();
                }
                else // continue on existing direction
                {
                    // move one position
                    MoveOneStepBasedOnDirection();
                }
            }
        }

        /// <summary>
        /// Overrides abstract method in base class Ghost.
        /// ghost movement for single player
        /// </summary>
        public override void MoveGhost(Pacman pacman)
        {
            if (this.IsEaten)
            {
                FigureWhatToPrintOnExsitingPosition();
                GhostGoesHome();
                PrintEngine.PrintSymbol(this.Row, this.Column, this.Symbol);
                if (this.Row == this.HomeRow && this.Column == this.HomeColumn)
                {
                    this.Symbol = Maze.symbolGhostOrangePokey;
                    this.isEaten = false;
                }
            }
            else if (pacman.CanEatGhosts)
            {
                // crossroad
                if (IsCrossRoad())
                {
                    // might change direction
                    ChangeToWhereAvailableDirection();
                    // move one position
                    MoveOneStepBasedOnDirection();
                }
                else // continue on existing direction
                {
                    MoveOneStepBasedOnDirection();
                }
            }
            else if(!pacman.CanEatGhosts)
            {
                // crossroad
                if (IsCrossRoad())
                {
                    // might change direction
                    ChangeToWhereAvailableDirection();
                    // move one position
                    MoveOneStepBasedOnDirection();
                }
                else // continue on existing direction
                {
                    // move one position
                    MoveOneStepBasedOnDirection();
                }
            }
        }
    }
}
