﻿namespace Game
{
    class Bashful : Ghost
    {
        private int steps;

        public Bashful(int row, int column, char symbol)
            : base(row, column, symbol)
        {
            this.Direction = Way.Up;
            this.IsEaten = false;
            this.steps = 0;
            this.homeColumn = column;
            this.homeRow = row;
        }

        /// <summary>
        /// ghost movement for multi-player
        /// </summary>
        /// <param name="pacman1"></param>
        /// <param name="pacman2"></param>
        public override void MoveGhost(Pacman pacman1, Pacman pacman2)
        {
            if (this.IsEaten)
            {
                FigureWhatToPrintOnExsitingPosition();
                GhostGoesHome();
                PrintEngine.PrintSymbol(this.Row, this.Column, this.Symbol);
                if (this.Row == this.HomeRow && this.Column == this.HomeColumn)
                {
                    this.Symbol = Maze.symbolGhostCyanBashful;
                    this.isEaten = false;
                }
            }
            else if (pacman1.CanEatGhosts || pacman2.CanEatGhosts)
            {
                // crossroad
                if (IsCrossRoad())
                {
                    // might change direction
                    ChangeToWhereAvailableDirection();
                    // move one position
                    MoveOneStepBasedOnDirection();
                }
                else // continue on existing direction
                {
                    MoveOneStepBasedOnDirection();
                }
            }
            else if (!pacman1.CanEatGhosts && !pacman2.CanEatGhosts)
            {
                // crossroad
                if (IsCrossRoad())
                {
                    // might change direction
                    ChangeToWhereAvailableDirection();
                    // move one position
                    MoveOneStepBasedOnDirection();
                }
                else // continue on existing direction
                {
                    // move one position
                    MoveOneStepBasedOnDirection();
                }
            }
        }

        /// <summary>
        /// ghost movement for single player
        /// </summary>
        /// <param name="pacman"></param>
        public override void MoveGhost(Pacman pacman)
        {

            if (this.IsEaten)
            {
                FigureWhatToPrintOnExsitingPosition();
                GhostGoesHome();
                PrintEngine.PrintSymbol(this.Row, this.Column, this.Symbol);
                if (this.Row == this.HomeRow && this.Column == this.HomeColumn)
                {
                    this.Symbol = Maze.symbolGhostCyanBashful;
                    this.isEaten = false;
                }
            }
            else if (pacman.CanEatGhosts)
            {
                // crossroad
                if (IsCrossRoad())
                {
                    ChangeToWhereAvailableDirection();
                    MoveOneStepBasedOnDirection();
                }
                else // continue on existing direction
                {
                    MoveOneStepBasedOnDirection();
                }
            }

            else if (!pacman.CanEatGhosts)
            {
                if (DistanceToPacman(pacman) > 15)
                {
                    // crossroad
                    if (IsCrossRoad())
                    {
                        // might change direction
                        ChangeToWhereAvailableDirection();
                        // move one position
                        MoveOneStepBasedOnDirection();
                    }
                    else // continue on existing direction
                    {
                        // move one position
                        MoveOneStepBasedOnDirection();
                    }
                }

                else
                {
                    FigureWhatToPrintOnExsitingPosition();

                    if (steps % 3 != 0)
                    {
                        Coordinates nextStep = this.FindNextStep(pacman.Row, pacman.Column);

                        this.row = nextStep.Row;
                        this.column = nextStep.Coll;

                        ChangeDirection(nextStep);
                    }
                    this.steps++;
                    PrintEngine.PrintSymbol(this.Row, this.Column, this.Symbol);
                }
            }
        }
    }
}

